<?php

namespace OCA\Chat;

class BackendNotFoundException extends \Exception {

}