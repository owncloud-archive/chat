<?php
$TRANSLATIONS = array(
"Chat" => "ਗੱਲਬਾਤ",
"Search in conversations" => "ਸੰਵਾਦ ਵਿੱਚ ਲਭੋ",
"Add Person" => "ਵਿਅਕਤੀ ਨੂੰ ਪਾਉਣਾ",
"Chat Message" => "ਗੱਲਬਾਤ ਸੁਨੇਹਾ",
"Search in users" => "ਵਰਤੋਂਕਾਰਾਂ ਵਿੱਚ ਲਭੋ",
"There are no other users on this ownCloud." => "ਇਸ ownCloud ਤੇ ਕੋਈ ਹੋਰ ਵਰਤੋਂਕਾਰ ਨਹੀਂ ਹੈ।"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
