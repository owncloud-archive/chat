<?php
$TRANSLATIONS = array(
"Chat" => "محادثة",
"Search in conversations" => "البحث في المحادثات",
"Add Person" => "إضافة شخص",
"Chat Message" => "رسالة الدردشة",
"Search in users" => "البحث في المستخدمين",
"There are no other users on this ownCloud." => "لا يوجد مستخدمين آخرين في هذا ال OwnClowd",
"In order to chat please create at least one user, it will appear on the left." => "من أجل الدردشة يجب عليك إنشاء مستخدم واحد على الأقل، سوف يظهر على اليسار."
);
$PLURAL_FORMS = "nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;";
