<?php
$TRANSLATIONS = array(
"Chat" => "চ্যাট করুন",
"Search in conversations" => "কথোপকথনে অনুসন্ধান করুন",
"Add Person" => "ব্যক্তি যোগ করুন",
"Chat Message" => "চ্যাট বার্তা",
"Search in users" => "ব্যবহারকারীদের মধ্যে অনুসন্ধান করুন",
"There are no other users on this ownCloud." => "এই ownCloud এ অন্য কোন ব্যবহারকারী নেই।"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
