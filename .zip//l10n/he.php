<?php
$TRANSLATIONS = array(
"Chat" => "שיחה",
"Search in conversations" => "חיפוש בשיחות",
"Add Person" => "הוספת חבר",
"Chat Message" => "הודעת שיחה",
"Search in users" => "חיפוש במשתמשים",
"There are no other users on this ownCloud." => "אין משתמשים נוספים ב- ownCloud הזה",
"In order to chat please create at least one user, it will appear on the left." => "כדי לבצע שיחה, יש ליצור לפחות משתמש אחד שיופיע בצד שמאל"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
