<?php
$TRANSLATIONS = array(
"Chat" => "Чат",
"New Conversation" => "Новая беседа",
"Hide Archived Conversations" => "Скрыть архивные сбеседы",
"Show Archived Conversations" => "Показать архивные беседы",
"Add Person" => "Добавить контакт",
"Chat Message" => "Сообщение",
"Click on a contact to add them to the conversation" => "Нажмите на контакте для добавления его в беседу",
"Click on a contact to start a conversation" => "Нажмите на контакте для начала беседы"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
