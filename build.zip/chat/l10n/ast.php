<?php
$TRANSLATIONS = array(
"Chat" => "Charra",
"Search in conversations" => "Guetar nes conversaciones",
"Add Person" => "Amestar persona",
"Chat Message" => "Mensaxe de charra",
"Search in users" => "Guetar nos usuarios",
"There are no other users on this ownCloud." => "Nun hai otros usuarios nesti ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Pa charrar escueyi polo menos un usuariu, por favor. Apaecerá na izquierda."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
