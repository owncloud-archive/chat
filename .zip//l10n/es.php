<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "Busque en las conversaciones",
"Add Person" => "Agregar persona",
"Chat Message" => "Mensaje",
"Search in users" => "Buscar en usuarios",
"There are no other users on this ownCloud." => "No hay otros usuarios en esta ownCloud",
"In order to chat please create at least one user, it will appear on the left." => "Para poder conversar, debe crear por lo menos un usuario; este aparecerá a la izquierda."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
