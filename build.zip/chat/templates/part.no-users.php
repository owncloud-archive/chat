<div ng-if="(contacts | count) === 1" id="no-users">
	<?php p($l->t('There are no other users on this ownCloud.')); ?><br />
	<?php p($l->t('In order to chat please create at least one user, it will appear on the left.')); ?><br />
</div>
