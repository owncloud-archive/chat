<?php
$TRANSLATIONS = array(
"Chat" => "Sohbet",
"Search in conversations" => "Konuşmalarda arama yap",
"Add Person" => "Kişi Ekle",
"Chat Message" => "Sohbet İletisi",
"Search in users" => "Kullanıcılarda ara",
"There are no other users on this ownCloud." => "Bu ownCloud üzerinde başka kullanıcı yok."
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
