<?php
$TRANSLATIONS = array(
"Chat" => "チャット",
"Search in conversations" => "会話を検索",
"Add Person" => "人を追加",
"Chat Message" => "チャットメッセージ",
"Search in users" => "ユーザーを検索",
"There are no other users on this ownCloud." => "このownCloudには他のユーザーはいません。"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
