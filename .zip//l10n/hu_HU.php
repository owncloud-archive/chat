<?php
$TRANSLATIONS = array(
"Chat" => "Csevegés",
"Search in conversations" => "Keresés a beszélgetésekben",
"Add Person" => "Személy Hozzáadása",
"Chat Message" => "Csevegö Üzenet",
"Search in users" => "Keresés a felhasználók között",
"There are no other users on this ownCloud." => "Nincs más felhasználó ebben az ownCloud-ban."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
