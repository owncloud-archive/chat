<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "In Unterhaltungen suchen",
"Add Person" => "Person hinzufügen",
"Chat Message" => "Chat-Nachricht",
"Search in users" => "In den Nutzern suchen",
"There are no other users on this ownCloud." => "Es befinden sich keine anderen Nutzer in dieser ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Um zu chatten erstellen Sie bitte mindestens einen Benutzer, dieser wird auf der linken Seite angezeigt."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
