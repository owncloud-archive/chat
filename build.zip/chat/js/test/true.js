describe('True', function () {
	it("True should equal true!", function(){
		expect(true).toBeTruthy();
	});
});