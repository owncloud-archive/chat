<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "Search in conversations",
"Add Person" => "Add Person",
"Chat Message" => "Chat Message",
"Search in users" => "Search in users",
"There are no other users on this ownCloud." => "There are no other users on this ownCloud."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
