window.OC = {
	imagePath : function(app, path){
		return 'index.php/apps/' + app + path;
	}
};
oc_requesttoken = 'abc123';