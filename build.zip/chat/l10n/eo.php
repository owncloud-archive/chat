<?php
$TRANSLATIONS = array(
"Chat" => "Babilo",
"Search in conversations" => "Serĉi inter babiloj",
"Add Person" => "Aldoni ulon",
"Chat Message" => "Babilmesaĝo",
"Search in users" => "Serĉi inter uzantoj",
"There are no other users on this ownCloud." => "Estas neniu alia uzanto en ĉi tiu ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Por babili, bonvolu krei almenaŭ unu uzanton; ĝi aperos maldekstre."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
