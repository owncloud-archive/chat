<?php
$TRANSLATIONS = array(
"Chat" => "Prat",
"Search in conversations" => "Søk i samtaler",
"Add Person" => "Legg til person",
"Chat Message" => "Pratmelding",
"Search in users" => "Søk i brukere",
"There are no other users on this ownCloud." => "Det er ingen andre brukere på denne installasjonen av ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Vennligst opprett minst en bruker for å prate. Brukeren vil vises til venstre."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
