<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "Vyhledat v konverzacích",
"Add Person" => "Přidat osobu",
"Chat Message" => "Zpráva chatu",
"Search in users" => "Hledat mezi uživateli",
"There are no other users on this ownCloud." => "Na tomto ownCloud serveru nejsou žádní jiní uživatelé.",
"In order to chat please create at least one user, it will appear on the left." => "Pro fungování chatu je třeba mít vytvořené alespoň jedno uživatelské jméno, které se poté objeví na panelu vlevo."
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;";
