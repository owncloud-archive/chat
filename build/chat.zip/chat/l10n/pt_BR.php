<?php
$TRANSLATIONS = array(
"Chat" => "Bate papo",
"Search in conversations" => "Pesquisar em conversas",
"Add Person" => "Adicionar uma Pessoa",
"Chat Message" => "Mensagem de Bate-Papo",
"Search in users" => "Pesquisar em usuários",
"There are no other users on this ownCloud." => "Não há outros usuários neste ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Para bater papo por favor crie pelo menos um usuário, isto irá aparecer a esquerda."
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
