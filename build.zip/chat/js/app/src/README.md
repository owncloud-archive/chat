JavaScript in the ownCloud Chat app
====

In this directory all JavaScript code is located which is only used for the [native]() ownCloud Chat app.

