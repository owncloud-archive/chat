<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"New Conversation" => "Conversație noua",
"Hide Archived Conversations" => "Ascunde conversațiile arhivate",
"Show Archived Conversations" => "Arata conversațiile arhivate",
"Add Person" => "Adauga persoana",
"Chat Message" => "Transmite mesajul",
"Click on a contact to start a conversation" => "Faceți clic pe un contact pentru a începe o conversație"
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));";
