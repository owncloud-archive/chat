<?php
$TRANSLATIONS = array(
"Chat" => "Klepet",
"Search in conversations" => "Poišči v pogovorih",
"Add Person" => "Dodaj osebo",
"Chat Message" => "Sporočilo klepetanja",
"Search in users" => "Poišči med uporabniki",
"There are no other users on this ownCloud." => "Ni drugih uporabnikov oblaka ownCloud."
);
$PLURAL_FORMS = "nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);";
