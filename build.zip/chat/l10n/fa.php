<?php
$TRANSLATIONS = array(
"Chat" => "گفتگوی متنی",
"Search in conversations" => "جستجو در مکالمات",
"Add Person" => "افزودن فرد",
"Chat Message" => "پیغام چت",
"There are no other users on this ownCloud." => "کاربر دیگری در این سرور owncloud وجود ندارد.",
"\tIn order to chat please create at least one user, it will appear on the left." => "برای شروع گفتگو، لطفا حداقل یک کاربر ایجاد کنید. که در بخش سمت چپ قابل مشاهده است."
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
