angular.module('chat').value('session', {
	id: null,
	conv: null,
	user: {}
});
