<?php
$TRANSLATIONS = array(
"Chat" => "Conversation in directo",
"Search in conversations" => "Cerca in conversationes",
"Add Person" => "Adde persona",
"Chat Message" => "Message de conversation",
"Search in users" => "Cerca in usatores",
"There are no other users on this ownCloud." => "Il non ha alcun altere usatores in iste ownCloud",
"In order to chat please create at least one user, it will appear on the left." => "Pro poter conversar pro favor tu crea al minus un usator, illo apparera a le sinistra."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
