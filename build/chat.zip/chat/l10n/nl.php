<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "Zoeken in gesprekken",
"Add Person" => "Toevoegen persoon",
"Chat Message" => "Bericht",
"Search in users" => "Zoek binnen gebruikers",
"There are no other users on this ownCloud." => "Er zijn geen andere gebruikers in deze ownCloud",
"In order to chat please create at least one user, it will appear on the left." => "Om te chatten, moet u minimaal één gebruiker aanmaken, die verschijnt links."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
