<?php
$TRANSLATIONS = array(
"Chat" => "Chat",
"Search in conversations" => "Cerca nelle conversazioni",
"Add Person" => "Aggiungi persona",
"Chat Message" => "Messaggio di chat",
"Search in users" => "Cerca tra gli utenti",
"There are no other users on this ownCloud." => "Non ci sono altri utenti in questo ownCloud.",
"In order to chat please create at least one user, it will appear on the left." => "Per iniziare una chat, crea almeno un utente, apparirà a sinistra."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
