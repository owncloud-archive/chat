OC.L10N.register(
    "chat",
    {
    "Chat" : "Chat",
    "{displayname} attached {path} to this conversation" : "{displayname} koppelde {path} aan dit gesprek",
    "{displayname} removed {path} from this conversation" : "{displayname} verwijderde {path} uit dit gesprek",
    "Start a chat with ..." : "Start een gesprek met ...",
    "Search in conversations" : "Zoeken in gesprekken",
    "Add Person" : "Toevoegen persoon",
    "View Attached files" : "Bekijk gekoppelde bestanden",
    "Chat Message" : "Bericht",
    "Files attached to this conversation" : "Bestanden gekoppeld aan dit gesprek",
    "Download " : "Download ",
    "Attach more files" : "Koppel meer bestanden",
    "Search in users" : "Zoek binnen gebruikers",
    "There are no Chat Backends enabled." : "Er zijn geen Chat backend geactiveerd.",
    "In order to chat please enable at least one Chat backend." : "Om te chatten, moet u minimaal één Chat backend activeren.",
    "With the 'OCH' backend you can chat with other ownCloud users. It works without configuration." : "Met de 'OCH' backend kunt u chatten met andere ownCloud gebruikers. Dit werkt zonder verdere configuratie.",
    "It can be enabled by running the following command in the root of your ownCloud installation:" : "Dit kan worden geactiveerd door het volgende commando in de root van uw ownCloud installatie uit te voeren:",
    "There are no other users on this ownCloud." : "Er zijn geen andere gebruikers in deze ownCloud",
    "In order to chat please create at least one user, it will appear on the left." : "Om te chatten, moet u minimaal één gebruiker aanmaken; deze verschijnt links."
},
"nplurals=2; plural=(n != 1);");
