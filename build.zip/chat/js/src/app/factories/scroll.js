//angular.module('chat').factory('scroll', [function() {
//	return {
//		scrollTop: function () {
//			$(".nano").nanoScroller();
//			setTimeout(function () {
//				$(".nano").nanoScroller({ scroll: 'top' });
//			},100);
//		},
//		scrollBottom: function () {
//			$(".nano").nanoScroller();
//			setTimeout(function () {
//				$(".nano").nanoScroller({ scroll: 'bottom' });
//			},100);
//		}
//	};
//}]);
