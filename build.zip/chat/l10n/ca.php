<?php
$TRANSLATIONS = array(
"Chat" => "Xat",
"Search in conversations" => "Cerca en les converses",
"Add Person" => "Afegeix Persona",
"Chat Message" => "Missatge de xat",
"Search in users" => "Cerca en els usuaris",
"There are no other users on this ownCloud." => "No hi ha altres usuaris en aquest ownCloud",
"In order to chat please create at least one user, it will appear on the left." => "Per xatejar siusplau crea almenys un usuari, apareixerà a l'esquerra"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
