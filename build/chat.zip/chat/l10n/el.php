<?php
$TRANSLATIONS = array(
"Chat" => "συνομιλία",
"Search in conversations" => "Αναζήτηση στις συζητήσεις",
"Add Person" => "Προσθήκη Ατόμου",
"Chat Message" => "Μύνημα Συνομιλίας",
"Search in users" => "Αναζήτηση χρηστών",
"There are no other users on this ownCloud." => "Δεν υπάρχουν άλλοι χρήστες σε αυτό το ownCloud."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
