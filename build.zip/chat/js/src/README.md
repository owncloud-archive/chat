JavaScript in the ownCloud Chat app
====

In this directory all JavaScript code is located which is common for both the [native]()  as the [integrated]() ownCloud app.
