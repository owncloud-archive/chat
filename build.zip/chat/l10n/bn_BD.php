<?php
$TRANSLATIONS = array(
"Chat" => "আলাপ",
"Search in conversations" => "কথোপকথনে খুঁজুন",
"Add Person" => "ব্যক্তিকে যুক্ত করুন",
"Chat Message" => "আলাপের বার্তা",
"Search in users" => "ব্যবহারকারীদের মাঝে খুঁজুন",
"There are no other users on this ownCloud." => "এই ওনক্লাউডে অন্যকোন ব্যবহারকারী নেই",
"In order to chat please create at least one user, it will appear on the left." => "চ্যাট করতে অন্ততপক্ষে একটি ব্যবহারকারী তৈরী করুন। এটি বামপাশে দেখা যাবে।"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
