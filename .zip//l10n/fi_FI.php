<?php
$TRANSLATIONS = array(
"Chat" => "Keskustelu",
"Search in conversations" => "Etsi keskusteluista",
"Add Person" => "Lisää henkilö",
"Chat Message" => "Viesti",
"Search in users" => "Etsi käyttäjistä",
"There are no other users on this ownCloud." => "Tässä ownCloudissa ei ole muita käyttäjiä.",
"In order to chat please create at least one user, it will appear on the left." => "Luo vähintään yksi käyttäjä, jotta voit keskustella. Käyttäjät ilmestyvät näkyviin vasemmalle."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
