<?php
$TRANSLATIONS = array(
"Chat" => "আলাপ",
"Search in conversations" => "কথোপকথনে খুঁজুন",
"Add Person" => "ব্যক্তিকে যুক্ত করুন",
"Chat Message" => "আলাপের বার্তা",
"Search in users" => "ব্যবহারকারীদের মাঝে খুঁজুন",
"There are no other users on this ownCloud." => "এই ওনক্লাউডে অন্যকোন ব্যবহারকারী নেই"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
